/* export.js */
function downloadCsv(content, filename) {
  const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
  const blob = new Blob([bom, content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
function downloadJson(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
function backupAllData() {
  const data = { appState, version: '1.4.0', timestamp: new Date().toISOString() };
  downloadJson(data, '\uC218\uB9C8\uD2B8\uD559\uAE09_\uC804\uCCB4\uBC31\uC5C5_' + todayStr() + '.json');
  showToast('\uC804\uCCB4 \uB370\uC774\uD130 \uBC31\uC5C5 \uD30C\uC77C\uC774 \uC11D\uC131\uB418\uC5C8\uC2B5\uB2C8\uB2E4.');
}
function restoreFromJson(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      let newAppState = null;
      if (data.appState) newAppState = data.appState;
      else if (data.classes && Array.isArray(data.classes)) newAppState = data;

      if (newAppState) {
        if (typeof window.appState === 'object') {
          Object.assign(window.appState, newAppState);
        } else {
          window.appState = newAppState;
        }
        
        if (typeof window.saveState === 'function') {
          // 강제로 localStorage에 새 상태 덮어쓰기 (클로저 회피용)
          localStorage.setItem('smartClassState', JSON.stringify(newAppState));
        }
        
        alert('\uB370\uC774\uD130 \uBCF5\uC6D0\uC774 \uC644\uB8CC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.');
        location.reload();
      } else {
        alert('\uC62C\uBC14\uB978 \uC218\uB9C8\uD2B8 \uD559\uAE09 \uBC31\uC5C5 \uD30C\uC77C\uC774 \uC544\uB2D9\uB2C8\uB2E4.');
      }
    } catch (err) { alert('\uBCF5\uC6D0 \uC911 \uC624\uB958 \uBC1C\uC0DD: ' + err.message); }
  };
  reader.readAsText(file);
}
window.backupAllData = backupAllData;
window.restoreFromJson = restoreFromJson;
window.downloadCsv = downloadCsv;
window.downloadJson = downloadJson;
window.renderStats = () => {};
window.openReportConfigModal = () => {};
window.openPhraseManageModal = () => {};

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btnBackupData')?.addEventListener('click', backupAllData);
  document.getElementById('btnBackup')?.addEventListener('click', backupAllData);
  document.getElementById('btnRestoreData')?.addEventListener('click', () => {
    document.getElementById('restoreInput')?.click();
  });
  document.getElementById('restoreInput')?.addEventListener('change', (e) => restoreFromJson(e.target));
});
